<footer>
    <p>&copy; <?php echo date('Y'); ?> <?php bloginfo('name'); ?></p>
    <?php wp_footer(); ?>
</footer>
</body>

</html>